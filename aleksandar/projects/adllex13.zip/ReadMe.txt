ADllExports
Copyright (C) 2003-2004 Alexander Kamburov
This software is released under the terms of the
GNU General Public Licence v2 (See GPL.txt for more information)


--------------
 Information:
--------------
ADllExports is used to list the exported functions of a given DLL.