AFNConvert v1.0 (FREEWARE)
--------------------------------------------------
Convert DOS to Windows cyrillic file names
--------------------------------------------------
Programmer: Wise Guy
Home Page: wiseguy.hit.bg
E-mail: wise_guybg@yahoo.com