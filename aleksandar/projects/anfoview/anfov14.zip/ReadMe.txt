________________________________________________

ANFOView v1.4 (FREEWARE)

This is a viewer for NFO and DIZ files.
________________________________________________

Programmer: Wise Guy
Home Page: http://wiseguy.hit.bg
E-mail: wise_guybg@yahoo.com