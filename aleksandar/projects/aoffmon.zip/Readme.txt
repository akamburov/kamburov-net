________________________________________________

AOffMon v1.0 (FREEWARE)

Puts you monitor in stad by mode
________________________________________________

Programmer: Wise Guy
Home Page: http://wiseguy.hit.bg
E-mail: wise_guybg@yahoo.com