APixel Color
Copyright (C) 2003-2007 Alexander Kamburov
This software is released under the terms of the
GNU General Public Licence v2 (See GPL.txt for more information)


--------------
 Information:
--------------
Get the value (RGB, HEX, Delphi) of a screen pixel color.