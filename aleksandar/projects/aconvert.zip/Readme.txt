AConvert v1.1 (FREEWARE)
--------------------------------------------------
Makes DOS cyrillic text files readable in Windows
--------------------------------------------------
Programmer: Wise Guy
Home Page: wiseguy.hit.bg
E-mail: wise_guybg@yahoo.com
--------------------------------------------------
Converting your old cyrillic text files with AConvert ensures you that you won't get "%#$%^" in Windows. The program is really easy to use.