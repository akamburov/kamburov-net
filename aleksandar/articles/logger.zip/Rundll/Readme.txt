-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-
ReadMe file for :
"Rundll v1.0" logger & "Decoder for sav files v1.0"
_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_


Programmed by WISE GUY
BULGARIA
wise_guybg@yahoo.com


~~~~~~~~~~~~~~~~~~~~~~~~~
TABLE of CONTENTS:
~~~~~~~~~~~~~~~~~~~~~~~~~

1. INTRODUCTION

2. INSTALLATION

3. USAGE

4. COMMANDS

5. CONFIGURATION

6. CONTACTS




~~~~~~~~~~~~~~~~~~~~~~~~~
1. INTRODUCTION
~~~~~~~~~~~~~~~~~~~~~~~~~
  Thank you for using "Rundll v1.0" !!! This is not an ordinary key logger - the program has a lot of network functions and other special features. Please read this help file to learn more about it. The "USAGE" part is very important !!!


~~~~~~~~~~~~~~~~~~~~~~~~~
2. INSTALLATION
~~~~~~~~~~~~~~~~~~~~~~~~~
  To install it on a PC copy the Rundll.exe file in the WINDOWS\SYSTEM directory.  If you want to install it on a remote PC copy the Rundll.exe file in its  WINDOWS\SYSTEM system directory and place a shortcut ( named:  Rundll   target:  C:\Windows\System\Rundll.exe ) in the Programs\StartUp  directory in the Start Menu ( MIND that "Rundll v1.0" will automaticly delete the shortcut when the computer restarts and will register itself in the Windows Registry ).
 

~~~~~~~~~~~~~~~~~~~~~~~~~
3. USAGE
~~~~~~~~~~~~~~~~~~~~~~~~~
  "Rundll v1.0" gets every key that you press and the changing of the active window, it can also paste the contents of the clipboard. You can use the program if you want to get a password,  to spy someone,  etc. This software is made speacially for Internet Cafes and Game Clubs which are widely spread in my country. The program can be downloaded and installed on the computer,  then on another,  then on another,  then on another,  then on another,  then on another,  then on another,  then on another,  then on another ,  then on another,  then on another and so on. Soon you'll be able to control all the computers in the network. You can restart them or send a message to the beautiful girl sitting next to you only by writting commands in the notepad or another window scanned by  "Rundll v1.0" ( Yes, that's right, you can't write commands where ever you want but ONLY in the specified windows ).
  "Rundll v1.0" creates two files - a CFG and a SAV file. The CFG file is nothing but a INI file but it is renamed so that no one will suspect anything about it or will try to view what it contains. The SAV file is partially encrypted. It's the log file where "Rundll v1.0" writes the pressed keys and active windows. You have to get this file and then you can find there all you want. To decode the file you'll need  "Decoder for sav files v1.0" ( maybe present in the archive file ). This decoder is simple. First select the file to decode and then the file where to write the decoded characters, that's all.
  "Rundll v1.0" &  "Decoder for sav files v1.0" are easy to use. If you find any bugs or you encounter any difficulties send me an e-mail.
  Please read " COMMANDS" to learn more about the things you can do with "Rundll v1.0"

~~~~~~~~~~~~~~~~~~~~~~~~~
4. COMMANDS
~~~~~~~~~~~~~~~~~~~~~~~~~
[MAIN]
These commands are used for the PC you are sitting on:

;about;                                Show about box
- learn more about the program

;beep;                                 Enable\Disable beep to verify commands
- this option is useful when you want to be sure that the command you typed has been accomplished  ( check  its value with ";status;" )

;cfghelp;                             Show CFG substituted names
- the CFG's keys names are replaced with numbers so that no one will suspect anything about this INI file

;cmd;pcname;command;    Send <command> to <pcname>
- use it to send commands to "Rundll v1.0" logger on a remote computer which name is specified in the <pcname> parameter
  eg.: ;cmd;PC01;sh; - this will shut down PC01 if  "Rundll v1.0" is installed on that computer
 TIP: If you type:
            ;cmd;;command;
       i.e. you omit <pcname> , the computer will send the <command> to the PC it last did

;copyf;                               Copy sav file to a:\
- copies SAV file to the floppy disk but only if SAV file size is less than 1,4MB

;deletef;                             Delete sav file
- use it if the SAV file is to large or if you just need to delete it

;editcfg;                             Open CFG file with NotePad(for editting)
- when you want to edit the CFG manually or to set a user window to spy

;end;                                   Stop executing commands
- use it to decrease the possibility of unautorised users to write commands (disables all the commands except ";start;")

;exit;                                   Exit
- only exits the program --> the next time the computer starts it will run again

;lines;number;                    Set <number> lines to add to SAV file
- the number must not  be smaller than 10 ( "Rundll v1.0" will write too frequently to the hard disk ) and larger than ~10000 ( "Rundll v1.0" will have to write a huge  text to the hard disk )
 WARNING:  Be careful because the keys are written in a single line

;paste;                               Enable\Disable Ctrl+V paste
- if you want to see the content of the clipboard when someone presses CTRL+V then enable this option ( check  its value with ";status;" )

;readf;                                Read SAV file with Notepad (mind it's encrypted)
- BLA BLA BLA

;refresh;                             Refresh settings from CFG file (call after editting)
- use this after ";editcfg;" to refresh the variables' values

;remhelp;                            Show remote commands
- shows a window with the commands to use with ";cmd;"

;remove;                             Registry remove'n'Exit (Uninstall but NO files are deleted)
- not only exits  "Rundll v1.0" but also removes the Startup in the Windows Registry

;repeat;                             Repeat last "cmd" command
- BLA BLA BLA

;start;                                Start executing commands
- use it to enable all the commands that are disabled by ";end;"

;status;                               Show status of variables and windows to spy
- BLA BLA BLA and also BLA

;writew;                               Write active windows names
- Enable it if you want to see all the active windows and not only the one that is scanned  ( check  its value with ";status;" )

[REMOTE]
These commands are used with ";cmd;pcname;...;"(pcname - Name of remote computer(eg.: PC01))  and are sent to the remote PC:

b?                  Beep - enabled or disabled
b=(0 or 1)        Enable(1)\Disable(0) beep
cl                   Close active window
de                  Delete sav file
ex                   Check the existing of the program and is it running
l?                    Check the value of the "lines to save" variable
l&                   Equalize the lines to save with yours
meMessage    Messagebox with <Message>
mi                   Minimize active window
p?                  Paste - enabled or disabled
p=(0 or 1)         Enable(1)\Disable(0) paste
re                   Restart the remote computer
sh                  Shutdown the remote computer
s?                  Started or not 
s=(0 or 1)         Enable(1)\Disable(0) start
un                   Uninstall program from the remote computer( no files are deleted - works like ";remove;" but on the remote computer )
w?                   Write Active Windows Names or not
w=(0 or 1)        Enable(1)\Disable(0) Write Active Windows Names
w&                  Equalize CFG windows' strings with yours


~~~~~~~~~~~~~~~~~~~~~~~~~
5. CONFIGURATION
~~~~~~~~~~~~~~~~~~~~~~~~~
  These are the CFG substituted names:

[Variables] - program variables
0 - Executing commands (0/1)
1 - Pasting from clipboard (0/1)
2 - Beep to verify commands (0/1)
3 - Write active windows names (0/1)
4 - Lines to save to file (10<number<100)

[Windows] - 10 user selectable windows to spy
0 -> 9  (Strings)
eg.: 0=MyString
       1=APass
       2=Readme.txt - Notepad


~~~~~~~~~~~~~~~~~~~~~~~~~
6. CONTACTS
~~~~~~~~~~~~~~~~~~~~~~~~~
  You can send me an e-mail at  wise_guybg@yahoo.com  and I'll answer your questions or try to solve your problems. E-mail me even to congratulate me on this great program ( I'll be very 'happy - puppy' as I like to say). Thanks again for using "Rundll v1.0" !!!


IMPORTANT NOTES:

* Both "Rundll v1.0" and "Decoder for sav files v1.0" are FREEWARE  ( or E-MAILWARE - you have to e-mail me if you'll use this programs - NOT really necessary )
* "Rundll v1.0" AND "Decoder for sav files v1.0"  ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND.